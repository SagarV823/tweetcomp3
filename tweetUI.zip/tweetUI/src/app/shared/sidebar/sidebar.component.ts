import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SearchUserTweetComponent } from 'src/app/featuremodules/tweet/search-user-tweet/search-user-tweet.component';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {

  @Input() loggedInUser = localStorage.getItem("email");
  imgurl="https://png.pngtree.com/png-vector/20191116/ourmid/pngtree-businessman-avatar-icon-vector-download-vector-user-icon-avatar-silhouette-social-png-image_1991050.jpg"
  
  constructor(private router:Router) { 
    if(this.router.url.includes(".com")){
      this.imgurl="https://e7.pngegg.com/pngimages/328/599/png-clipart-male-avatar-user-profile-profile-heroes-necktie-thumbnail.png";
    }
  }

  ngOnInit(): void {
  }

}
