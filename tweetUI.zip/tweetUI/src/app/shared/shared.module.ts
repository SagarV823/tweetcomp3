import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TweetRoutingModule } from '../featuremodules/tweet/tweet-routing.module';
import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';

@NgModule({
  declarations: [HeaderComponent, SidebarComponent],
  imports: [
    CommonModule,
    TweetRoutingModule
  ],
  exports: [HeaderComponent, SidebarComponent]
})
export class SharedModule { }
