export interface Tweet {
    id: number;
    email: string;
    tweetPost: string;
    date: Date;
    likeBy: string[];
}