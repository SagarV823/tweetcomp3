import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Reply } from '../models/reply.model';
import { Tweet } from '../models/tweet.model';
import { User } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class TweetService {
  constructor(private httpClient: HttpClient) { }

  viewallUsers(): Observable<User> {
    const baseUrl = "http://localhost:8090/api/v1.0/tweets/users/all";
    return this.httpClient.get<User>(baseUrl);
  }

  viewallTweets(): Observable<Tweet> {
    const baseUrl = "http://localhost:8090/api/v1.0/tweets/all";
    return this.httpClient.get<Tweet>(baseUrl);
  }

  createTweet(newTweet): Observable<Tweet> {
    const baseUrl = "http://localhost:8090/api/v1.0/tweets/add";
    return this.httpClient.post<Tweet>(baseUrl, newTweet);
  }

  putTweet(id, newTweet): Observable<Tweet> {
    const baseUrl = "http://localhost:8090/api/v1.0/tweets/like";
    return this.httpClient.put<Tweet>(baseUrl, newTweet);
  }

  resetPassword(newPassword): Observable<any> {
    const baseUrl = "http://localhost:8090/api/v1.0/tweets/reset";
    return this.httpClient.put<any>(baseUrl, newPassword);
  }

  viewallReply(): Observable<Reply> {
    const baseUrl = "http://localhost:8090/api/v1.0/tweets/allReply";
    return this.httpClient.get<Reply>(baseUrl);
  }

  replyTweet(newReply): Observable<Reply> {
    const baseUrl = "http://localhost:8090/api/v1.0/tweets/reply";
    return this.httpClient.post<Reply>(baseUrl, newReply);
  }

  getMyTweet(email): Observable<Tweet> {
    const baseUrl = "http://localhost:8090/api/v1.0/tweets";
    return this.httpClient.get<Tweet>(`${baseUrl}/${email}`);
  }

  getUser(email): Observable<any> {
    const baseUrl = "http://localhost:8090/api/v1.0/tweets/users";
    return this.httpClient.get<any>(`${baseUrl}/${email}`);
  }

  deleteTweet(tweetId): Observable<Tweet> {
    const baseUrl = "http://localhost:8090/api/v1.0/tweets";
    return this.httpClient.delete<Tweet>(`${baseUrl}/${tweetId}`);
  }

  deleteTweetReply(tweetId): Observable<Reply> {
    const baseUrl = "http://localhost:8090/api/v1.0/tweets/comment";
    return this.httpClient.delete<Reply>(`${baseUrl}/${tweetId}`);
  }
}
