import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private httpClient:HttpClient) { }

  createUser(newUser):Observable<User>{
    const baseUrl="http://localhost:8090/api/v1.0/tweets/register";
    return this.httpClient.post<User>(baseUrl,newUser);
  }

  getUser(email): Observable<any> {
    const baseUrl = "http://localhost:8090/api/v1.0/tweets/users";
    return this.httpClient.get<any>(`${baseUrl}/${email}`);
  }

  forgot(email): Observable<any> {
    const baseUrl = "http://localhost:8090/api/v1.0/tweets/forgot";
    return this.httpClient.get<any>(`${baseUrl}/${email}`);
  }

  resetPassword(newPassword): Observable<any> {
    const baseUrl = "http://localhost:8090/api/v1.0/tweets/reset";
    return this.httpClient.put<any>(baseUrl, newPassword);
  }
}
