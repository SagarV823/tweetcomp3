import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  loginUrl="http://localhost:8090/api/v1.0/tweets";

  constructor(private httpClient:HttpClient, private router: Router) { }

  generateToken(credentials:any){
    localStorage.setItem("email",credentials.email)
    return this.httpClient.post(this.loginUrl,credentials)
  }

  loginUser(token){
    localStorage.setItem("token",token)
    return true;
  }

  isLoggedIn(){
    let token=localStorage.getItem("token");
    if(token!=undefined||token!==''||token!=null){
      localStorage.removeItem("email")
      return false;
    }else
    {
      return true;
    }
  }
  
  logout(){
    localStorage.removeItem('token')
    localStorage.removeItem("email")
    this.router.navigate(['']);
    return true;
  }

  getToken(){
    return localStorage.getItem("token");
  }
}
