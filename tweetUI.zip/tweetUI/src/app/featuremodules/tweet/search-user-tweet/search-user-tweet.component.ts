import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { TweetService } from 'src/app/services/tweet.service';

@Component({
  selector: 'app-search-user-tweet',
  templateUrl: './search-user-tweet.component.html',
  styleUrls: ['./search-user-tweet.component.scss']
})
export class SearchUserTweetComponent implements OnInit {
  
  viewAllTweets:any;
  viewAllReply:any;
  replyForm: FormGroup;
  email:any;
  tweetId:any;
  commentBox:any;
  replyId:any;
  singleData:any=[];
  commentOnTweet = true;
  showSearchedUser = false;  
  date = new Date();
  loggedInUser=localStorage.getItem("email");
  
  constructor(private tweetService: TweetService, private fb: FormBuilder, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.replyId = Math.floor(Math.random() * (999 - 100 + 1) + 100);

    this.activatedRoute.params.subscribe(data=>{
      this.email=data.email;
      console.log(this.email);
    });
    // this.singleData = [
    //   {
    //     id: 1,
    //     email: "vermapiyush@123gmail.com",
    //     tweetPost: "Nice day",
    //     date: new Date(),
    //     likeBy: ["vermapiyush@123gmail.com","vermasahil@123gmail.com","vermaaarti@123gmail.com"]
    //   },
    //   {
    //     id: 2,
    //     email: "vermapiyush@123gmail.com",
    //     tweetPost: "last day at office",
    //     date: new Date(),
    //     likeBy: ["vermapiyush@123gmail.com"]
    //   },
    //   {
    //     id: 3,
    //     email: "vermapiyush@123gmail.com",
    //     tweetPost: "Nice day",
    //     date: new Date(),
    //     likeBy: ["vermapiyush@123gmail.com","vermaaarti@123gmail.com"]
    //   }
    // ];
    // this.viewAllReply = [
    //   {
    //     id: 1,
    //     tweetId: 1,
    //     email: "xyz@gmail.com",
    //     tweetReply: "oh ok nice",
    //     date: new Date
    //   },
    //   {
    //     id: 2,
    //     tweetId: 1,
    //     email: "xyz2@gmail.com",
    //     tweetReply: "yes it is",
    //     date: new Date
    //   },
    //   {
    //     id: 3,
    //     tweetId: 2,
    //     email: "xyz2@gmail.com",
    //     tweetReply: "oh ok nice",
    //     date: new Date
    //   },
    //   {
    //     id: 4,
    //     tweetId: 3,
    //     email: "xyz3@gmail.com",
    //     tweetReply: "yes it is",
    //     date: new Date
    //   }
    // ];
    this.tweetService.getMyTweet(this.email).subscribe(
      data => {
        this.viewAllTweets = data;
        console.log(this.viewAllTweets);
        if (this.viewAllTweets.length == 0) {
          this.showSearchedUser = true;
        }
      },
      error => {
        console.log(error.error);
        
      }
    );

    this.tweetService.viewallTweets().subscribe(
      data => {
      this.viewAllTweets = data;
      console.log(this.viewAllTweets);
      for(let x=0;x<this.viewAllTweets.length;x++){
        if(this.viewAllTweets[x].email==this.email){
          this.singleData.push(this.viewAllTweets[x])
        }
      }
      },
      error => {
        console.log(error.error);
        
      }
    );

    this.tweetService.viewallReply().subscribe(
      data => {
      this.viewAllReply = data;
      console.log(this.viewAllReply);
      },
      error => {
        console.log(error.error);
        
      }
    );

    this.replyForm = this.fb.group({
      tweetReply: ['', Validators.required],
    });
  }

  comment(id,i): void {
    this.commentBox=i;
    this.tweetId=id;
    if (this.commentOnTweet) {
      this.commentOnTweet=false;
    }
    else {
      this.commentOnTweet=true;
    }
  }

  onReply(form: FormGroup): void {
    console.log('reply', form.value.tweetReply);
    let newReply = {
      id: this.replyId,
      tweetId:this.tweetId,
      email: localStorage.getItem("email"),
      tweetReply: form.value.tweetReply,
      date: this.date
    };
    console.log(newReply);
    this.tweetService.replyTweet(newReply).subscribe(
      data => {
      console.log(data);
      this.ngOnInit();
      },
      error => {
        console.log(error.error);
        
      }
    );
  }

  like(tweet): void {
    console.log(tweet.likeBy);
    if(tweet.likeBy.includes(localStorage.getItem("email")))
    {
      tweet.likeBy.pop(localStorage.getItem("email"));
      console.log(tweet.likeBy);
      let newLike = {
        id: tweet.id,
        email: tweet.email,
        tweetPost: tweet.tweetPost,
        date: tweet.date,
        likeBy:tweet.likeBy
      };
      console.log(newLike);
      this.tweetService.putTweet(tweet.id,newLike).subscribe(
        data => {
          console.log(data);
        },
        error => {
          console.log(error.error);
          
        }
      );
    }
    else{
      tweet.likeBy.push(localStorage.getItem("email"));
      console.log(tweet.likeBy);
      let newLike = {
        id: tweet.id,
        email: tweet.email,
        tweetPost: tweet.tweetPost,
        date: tweet.date,
        likeBy:tweet.likeBy
      };
      console.log(newLike);
      this.tweetService.putTweet(tweet.id,newLike).subscribe(
        data => {
          console.log(data);
        },
        error => {
          console.log(error.error);
          
        }
      );
    }
  }
}
