import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TweetService } from 'src/app/services/tweet.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  myForm: FormGroup;
  replyForm: FormGroup;
  viewAllTweets: any;
  viewAllReply: any;
  commentBox: any;
  tweetId: any;
  uid: any;
  replyId: any;
  commentOnTweet = true;
  date = new Date();
  loggedInUser = localStorage.getItem("email");

  constructor(private tweetService: TweetService,private fb: FormBuilder) { }

  ngOnInit(): void {

    this.uid = Math.floor(Math.random() * (999 - 100 + 1) + 100);
    this.replyId = Math.floor(Math.random() * (999 - 100 + 1) + 100);

    // this.viewAllTweets = [
    //   {
    //     id: 1,
    //     email: "vermapiyush@123gmail.com",
    //     tweetPost: "Nice day",
    //     date: new Date(),
    //     likeBy: ["vermapiyush@123gmail.com","vermasahil@123gmail.com","vermaaarti@123gmail.com"]
    //   },
    //   {
    //     id: 2,
    //     email: "vermasagar@123gmail.com",
    //     tweetPost: "last day at office",
    //     date: new Date(),
    //     likeBy: ["vermapiyush@123gmail.com"]
    //   },
    //   {
    //     id: 3,
    //     email: "dineshjainh@123gmail.com",
    //     tweetPost: "Nice day",
    //     date: new Date(),
    //     likeBy: ["vermapiyush@123gmail.com","vermaaarti@123gmail.com"]
    //   }
    // ];
    // this.viewAllReply = [
    //   {
    //     id: 1,
    //     tweetId: 1,
    //     email: "xyz@gmail.com",
    //     tweetReply: "oh ok nice",
    //     date: new Date
    //   },
    //   {
    //     id: 2,
    //     tweetId: 1,
    //     email: "xyz2@gmail.com",
    //     tweetReply: "yes it is",
    //     date: new Date
    //   },
    //   {
    //     id: 3,
    //     tweetId: 2,
    //     email: "xyz2@gmail.com",
    //     tweetReply: "oh ok nice",
    //     date: new Date
    //   },
    //   {
    //     id: 3,
    //     tweetId: 2,
    //     email: "xyz3@gmail.com",
    //     tweetReply: "yes it is",
    //     date: new Date
    //   }
    // ];
    this.tweetService.viewallTweets().subscribe(
      data => {
      this.viewAllTweets = data;
      console.log(this.viewAllTweets);
      },
      error => {
        console.log(error.error);
        
      }
    );

    this.tweetService.viewallReply().subscribe(
      data => {
      this.viewAllReply = data;
      console.log(this.viewAllReply);
      },
      error => {
        console.log(error.error);
        
      }
    );

    this.myForm = this.fb.group({
      tweetPost: ['', Validators.required],
    });

    this.replyForm = this.fb.group({
      tweetReply: ['', Validators.required],
    });
  }

  onSubmit(form: FormGroup): void {
    console.log('tweet', form.value.tweetPost);
    let newTweet = {
      id: this.uid,
      email: localStorage.getItem("email"),
      tweetPost: form.value.tweetPost,
      date: this.date,
      likeBy: []
    };
    console.log(newTweet);
    this.tweetService.createTweet(newTweet).subscribe(
      data => {
      console.log(data);
      this.ngOnInit();
      },
      error => {
        console.log(error.error);
        
      }
    );
  }

  comment(id, i): void {
    this.commentBox = i;
    this.tweetId = id;
    if (this.commentOnTweet) {
      this.commentOnTweet = false;
    }
    else {
      this.commentOnTweet = true;
    }
  }

  onReply(form: FormGroup): void {
    console.log('reply', form.value.tweetReply);
    let newReply = {
      id: this.replyId,
      tweetId: this.tweetId,
      email: localStorage.getItem("email"),
      tweetReply: form.value.tweetReply,
      date: this.date
    };
    console.log(newReply);
    this.tweetService.replyTweet(newReply).subscribe(
      data => {
      console.log(data);
      this.ngOnInit();
      },
      error => {
        console.log(error.error);
        
      }
    );
  }

  like(tweet): void {
    console.log(tweet.likeBy);
    if (tweet.likeBy.includes(localStorage.getItem("email"))) {
      tweet.likeBy.pop(localStorage.getItem("email"));
      console.log(tweet.likeBy);
      let newLike = {
        id: tweet.id,
        email: tweet.email,
        tweetPost: tweet.tweetPost,
        date: tweet.date,
        likeBy: tweet.likeBy
      };
      console.log(newLike)
      this.tweetService.putTweet(tweet.id,newLike).subscribe(
        data => {
          console.log(data);
        },
        error => {
          console.log(error.error);
          
        }
      );
    }
    else {
      tweet.likeBy.push(localStorage.getItem("email"));
      console.log(tweet.likeBy);
      let newLike = {
        id: tweet.id,
        email: tweet.email,
        tweetPost: tweet.tweetPost,
        date: tweet.date,
        likeBy: tweet.likeBy
      };
      console.log(newLike)
      this.tweetService.putTweet(tweet.id,newLike).subscribe(
        data => {
          console.log(data);
        },
        error => {
          console.log(error.error);
          
        }
      );
    }
  }
}
