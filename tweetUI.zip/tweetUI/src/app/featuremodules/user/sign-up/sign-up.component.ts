import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss']
})
export class SignUpComponent implements OnInit {

  myForm: FormGroup;
  uid: any;
  inputPassword = '';
  inputConfirmPassword = '';
  submitted = false;
  mismatch = false;

  constructor(private UserService: UserService, private toastr: ToastrService, private fb: FormBuilder, private router: Router) { }

  ngOnInit(): void {
    this.uid = Math.floor(Math.random() * (999 - 100 + 1) + 100);
    this.myForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      contactNumber: ['', Validators.required],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    });
  }

  get registerFormControl() {
    return this.myForm.controls;
  }

  onKey(event: any): void {
    this.inputPassword = event.target.value;
  }

  checkPasswordMismatch(event: any): void {
    this.inputConfirmPassword = event.target.value;
    if (this.inputPassword != this.inputConfirmPassword) {
      this.mismatch = true;
    }
    else {
      this.mismatch = false;
    }
  }

  onSubmit(form: FormGroup): void {
    this.submitted = true;
    let newUser = {
      id: this.uid,
      firstName: form.value.firstName,
      lastName: form.value.lastName,
      email: form.value.email,
      password: form.value.password,
      contactNumber: form.value.contactNumber,
    };
    console.log(newUser);
    this.UserService.createUser(newUser).subscribe(
      data => {
        console.log(data);
        // this.showToaster();
        this.router.navigate(['/log-in']);
      },
      error => {
        console.log(error.error);
        
      }
    );
  }

}
