package com.tweetapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.runner.RunWith;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.tweetapp.model.TweetModel;
import com.tweetapp.model.UserModel;
//import com.tweetapp.repository.TweetRepositoryy;
//import com.tweetapp.repository.UserRepositoryy;
import com.tweetapp.service.UserService;

@RunWith(SpringRunner.class)
@SpringBootTest
class WhistleApiApplicationTests {
//	@MockBean
//	private UserService service;
//
//	@MockBean
//	private UserRepositoryy repository;
//
//	@MockBean
//	private TweetRepositoryy repo;
//
//	@Test
//	public void getUsersTest() {
//		when(repository.findAll()).thenReturn(
//				Stream.of(new UserModel(104, "oshi", "san", "oshi@gmail.com", "oshi12345", "7389493428"))
//						.collect(Collectors.toList()));
//		List<UserModel> expected = new ArrayList<UserModel>();
//		UserModel user = new UserModel(104, "oshi", "san", "oshi@gmail.com", "oshi12345", "7389493428");
//		expected.add(user);
//		List<UserModel> actual = repository.findAll();
//		assertEquals(expected, actual);
//	}
//
//	@Test
//	public void getTestEmail() {
//		String email = "oshi@gmail.com";
//		when(repository.findUserByEmail(email)).thenReturn((List<UserModel>) (new UserModel(104, "oshi", "san",
//				"oshi@gmail.com", "oshi12345", "7389493428")));
//		UserModel actual = (UserModel) repository.findUserByEmail(email);
//		UserModel expected = new UserModel(104, "oshi", "san", "oshi@gmail.com", "oshi12345", "7389493428");
//		assertEquals(expected, actual);
//	}
//
//	@Test
//	public void getTestAllTweet() {
//		String userid = "oshi@gmail.com";
//		List<String> a = new ArrayList<>();
//		a.add("san");
//		Date d = new Date();
//		when(repo.findUserByEmail(userid)).thenReturn(Stream
//				.of(new TweetModel(1234568, "oshi@gmail.com", "hi Anshul !!!!!", d, a)).collect(Collectors.toList()));
//		List<TweetModel> actual = repo.findUserByEmail(userid);
//		List<TweetModel> expected = new ArrayList<TweetModel>();
//		TweetModel t = new TweetModel(1234568, "oshi@gmail.com", "hi Anshul !!!!!", d, a);
//		expected.add(t);
//		assertEquals(expected, actual);
//	}
//
//	@Test
//	public void getTestTweets() {
//		List<String> a = new ArrayList<>();
//		a.add("san");
//		Date d = new Date();
//		when(repo.findAll()).thenReturn(Stream.of(new TweetModel(1234568, "oshi@gmail.com", "hi Anshul !!!!!", d, a))
//				.collect(Collectors.toList()));
//		List<TweetModel> actual = repo.findAll();
//		List<TweetModel> expected = new ArrayList<TweetModel>();
//		TweetModel t = new TweetModel(1234568, "oshi@gmail.com", "hi Anshul !!!!!", d, a);
//		expected.add(t);
//		assertEquals(expected, actual);
//	}
//
//	@Test
//	public void registerUserTest() {
//		UserModel user = new UserModel(104, "oshi", "san", "oshi@gmail.com", "oshi12345", "7389493428");
//		when(repository.insert(user))
//				.thenReturn(new UserModel(104, "oshi", "san", "oshi@gmail.com", "oshi12345", "7389493428"));
//		UserModel actual = repository.insert(user);
//		UserModel expected = new UserModel(104, "oshi", "san", "oshi@gmail.com", "oshi12345", "7389493428");
//		assertEquals(expected, actual);
//	}
//
//	@Test
//	public void setPasswordTest() {
//		UserModel userWithLoginId = new UserModel(104, "oshi", "san", "oshi@gmail.com", "oshi12345",
//				"7389493428");
//		when(repository.save(userWithLoginId))
//				.thenReturn(new UserModel(104, "oshi", "san", "oshi@gmail.com", "oshi12345", "7389493428"));
//		UserModel actual = repository.save(userWithLoginId);
//		UserModel expected = new UserModel(104, "oshi", "san", "oshi@gmail.com", "oshi12345", "7389493428");
//		assertEquals(expected, actual);
//	}
//
//	@Test
//	public void addTweetTest() {
//		List<String> a = new ArrayList<>();
//		a.add("san");
//		Date d = new Date();
//		TweetModel tweet = new TweetModel(1234568, "abc@gmail.com", "hi Anshul !!!!!", d, a);
//		when(repo.insert(tweet)).thenReturn(new TweetModel(1234568, "abc@gmail.com", "hi Anshul !!!!!", d, a));
//		TweetModel actual = repo.insert(tweet);
//		TweetModel expected = new TweetModel(1234568, "abc@gmail.com", "hi Anshul !!!!!", d, a);
//		assertEquals(expected, actual);
//	}
//
//	@Test
//	public void updateTweetTest() {
//		List<String> a = new ArrayList<>();
//		a.add("san");
//		Date d = new Date();
//		TweetModel updatedTweet = new TweetModel(1234568, "abc@gmail.com", "hi Anshul !!!!!", d, a);
//		when(repo.save(updatedTweet)).thenReturn(new TweetModel(1234568, "abc@gmail.com", "hi Anshul !!!!!", d, a));
//		TweetModel actual = repo.save(updatedTweet);
//		TweetModel expected = new TweetModel(1234568, "abc@gmail.com", "hi Anshul !!!!!", d, a);
//		assertEquals(expected, actual);
//	}
}