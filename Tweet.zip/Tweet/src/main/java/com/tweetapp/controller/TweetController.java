package com.tweetapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.model.AuthenticationResponse;
import com.tweetapp.model.TweetModel;
import com.tweetapp.model.TweetReplyModel;
import com.tweetapp.repository.TweetReplyRepository;
//import com.tweetapp.repository.TweetReplyRepositoryy;
import com.tweetapp.repository.TweetRepository;
//import com.tweetapp.repository.TweetRepositoryy;
import com.tweetapp.service.TweetService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = "/api/v1.0/tweets")
public class TweetController {

	@Autowired
	public TweetRepository tweetRepository;

	@Autowired
	public TweetReplyRepository tweetReplyRepository;

	@Autowired
	public TweetService tweetService;

	@PostMapping(value = "/add")
	private ResponseEntity<?> postTweet(@RequestBody TweetModel tweetModel) {
		String email = tweetModel.getEmail();
		try {
			tweetRepository.save(tweetModel);
		} catch (Exception e) {
			return ResponseEntity.ok(new AuthenticationResponse("Error during Client Subscription" + email));
		}
		return ResponseEntity.ok(new AuthenticationResponse("Successfull Subscription For Client" + email));
	}

	@GetMapping(value = "/all")
	public ResponseEntity<List<TweetModel>> getAllTweets() {
		return ResponseEntity.ok(tweetService.getAllTweets());
	}

	@PutMapping(value = "/like")
	public ResponseEntity postLike(@RequestBody TweetModel tweetModel) {
		tweetService.postLike(tweetModel);
		return ResponseEntity.ok().build();
	}

	@PostMapping(value = "/reply")
	private ResponseEntity<?> postTweetReply(@RequestBody TweetReplyModel tweetReplyModel) {
		String email = tweetReplyModel.getEmail();
		try {
			tweetReplyRepository.save(tweetReplyModel);
		} catch (Exception e) {
			return ResponseEntity.ok(new AuthenticationResponse("Error during Client Subscription" + email));
		}
		return ResponseEntity.ok(new AuthenticationResponse("Successfull Subscription For Client" + email));
	}

	@GetMapping(value = "/allReply")
	public ResponseEntity<List<TweetReplyModel>> getAllTweetReply() {
		return ResponseEntity.ok(tweetService.getAllTweetReply());
	}

	@GetMapping("/{email}")
	public ResponseEntity<List<TweetModel>> getTweetsByEmail(@PathVariable String email) {
		return ResponseEntity.ok(tweetService.getTweetsByEmail(email));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity deleteTweet(@PathVariable Long id) {
		tweetService.deleteTweet(id);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}

//	@DeleteMapping("/comment/{tweetId}")
//	public ResponseEntity deleteTweetComment(@PathVariable Long tweetId) {
//		tweetService.deleteTweetComment(tweetId);
//		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
//	}
}
