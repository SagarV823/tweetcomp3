package com.tweetapp.service;

import java.util.List;

import com.tweetapp.model.TweetModel;
import com.tweetapp.model.TweetReplyModel;

public interface TweetService {
	
	public List<TweetModel> getAllTweets();
	
	public void postLike(TweetModel tweetModel);

	public List<TweetReplyModel> getAllTweetReply();

	public List<TweetModel> getTweetsByEmail(String email);

	public void deleteTweet(Long id);

	//public void deleteTweetComment(Long tweetId);

}
