package com.tweetapp.service;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetails;
import com.tweetapp.model.UserModel;

public interface UserService   {
	
	public UserDetails loadUserByUsername(String email); 
	
	public List<UserModel> getAllUsers();

	public UserModel getUsersByEmail(String email);

	public void resetPassword(UserModel userModel);
			

}













//@Service
//@Autowired
//public UserRepository userRepository;
//@Override
//throws UsernameNotFoundException
//{
// TODO Auto-generated method stub
//		UserModel foundedUser = userRepository.findByEmail(email);
//		if(foundedUser == null) return null;
//		String userEmail=foundedUser.getEmail();
//		String password=foundedUser.getPassword();		
//		return new User(userEmail,password,new ArrayList<>());
//}