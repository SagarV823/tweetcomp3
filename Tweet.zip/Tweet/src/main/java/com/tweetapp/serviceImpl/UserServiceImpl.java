package com.tweetapp.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.tweetapp.model.UserModel;
import com.tweetapp.repository.UserRepository;
//import com.tweetapp.repository.UserRepositoryy;
import com.tweetapp.service.UserService;

@Service
public class UserServiceImpl implements UserDetailsService, UserService {

	@Autowired
	public UserRepository userRepository;

	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		UserModel foundedUser = userRepository.findUserByEmail(email);
		if (foundedUser == null)
			return null;
		String userEmail = foundedUser.getEmail();
		String password = foundedUser.getPassword();
		return new User(userEmail, password, new ArrayList<>());
	}

	public List<UserModel> getAllUsers() {
		return userRepository.findAll();
	}

	@Override
	public UserModel getUsersByEmail(String email) {
		return userRepository.findUserByEmail(email);
	}

	@Override
	public void resetPassword(UserModel userModel) {
		UserModel singleUser = userRepository.findById(userModel.getId());
		//.orElseThrow(() -> new RuntimeException(String.format("Cannot Find User by ID %s", userModel.getId())));
		singleUser.setFirstName(userModel.getFirstName());
		singleUser.setLastName(userModel.getLastName());
		singleUser.setEmail(userModel.getEmail());
		singleUser.setPassword(userModel.getPassword());
		singleUser.setContactNumber(userModel.getContactNumber());
		userRepository.save(singleUser);
	}
}
