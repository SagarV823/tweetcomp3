package com.tweetapp.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.model.TweetModel;
import com.tweetapp.model.TweetReplyModel;
import com.tweetapp.repository.TweetReplyRepository;
//import com.tweetapp.repository.TweetReplyRepositoryy;
import com.tweetapp.repository.TweetRepository;
//import com.tweetapp.repository.TweetRepositoryy;
import com.tweetapp.service.TweetService;

@Service
public class TweetServiceImpl implements TweetService {

	@Autowired
	public TweetRepository tweetRepository;

	@Autowired
	public TweetReplyRepository tweetReplyRepository;

	@Override
	public List<TweetModel> getAllTweets() {
		return tweetRepository.findAll();
	}

	public void postLike(TweetModel tweetModel) {
		TweetModel singleUserLike = tweetRepository.findById(tweetModel.getId());
		//.orElseThrow(() -> new RuntimeException(String.format("Cannot Find User by ID %s", tweetModel.getId())));
		singleUserLike.setEmail(tweetModel.getEmail());
		singleUserLike.setTweetPost(tweetModel.getTweetPost());
		singleUserLike.setDate(tweetModel.getDate());
		singleUserLike.setLikeBy(tweetModel.getLikeBy());
		tweetRepository.save(singleUserLike);
	}

	@Override
	public List<TweetReplyModel> getAllTweetReply() {
		return tweetReplyRepository.findAll();
	}

	@Override
	public List<TweetModel> getTweetsByEmail(String email) {
		return (List<TweetModel>) tweetRepository.findUserByEmail(email);
	}

	@Override
	public void deleteTweet(Long id) {
		tweetRepository.deleteById(id);
	}

//	@Override
//	public void deleteTweetComment(Long tweetId) {
//		tweetReplyRepository.deleteTweetReplyModelByTweetId(tweetId);
//	}
}
