package com.tweetapp.model;

import java.util.Date;

//import org.springframework.data.annotation.Id;
//import org.springframework.data.mongodb.core.mapping.Document;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

//@Document(collection="reply")
@DynamoDBTable(tableName = "reply")
public class TweetReplyModel {
	
		//@Id
		@DynamoDBHashKey
    	private long id;
	
		@DynamoDBAttribute
		private long tweetId;
		
		@DynamoDBAttribute
		private String email;
		
		@DynamoDBAttribute
		private String tweetReply;
		
		@DynamoDBAttribute
		private Date date;

		public TweetReplyModel() {
			super();
		}

		public TweetReplyModel(long id, long tweetId, String email, String tweetReply, Date date) {
			super();
			this.id = id;
			this.tweetId = tweetId;
			this.email = email;
			this.tweetReply = tweetReply;
			this.date = date;
		}

		public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}

		public long getTweetId() {
			return tweetId;
		}

		public void setTweetId(long tweetId) {
			this.tweetId = tweetId;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getTweetReply() {
			return tweetReply;
		}

		public void setTweetReply(String tweetReply) {
			this.tweetReply = tweetReply;
		}

		public Date getDate() {
			return date;
		}

		public void setDate(Date date) {
			this.date = date;
		}
}
