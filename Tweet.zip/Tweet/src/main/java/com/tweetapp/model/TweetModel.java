package com.tweetapp.model;

import java.util.Date;
import java.util.List;

//import org.springframework.data.annotation.Id;
//import org.springframework.data.mongodb.core.mapping.Document;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

//@Document(collection="tweets")
@DynamoDBTable(tableName = "tweets")
public class TweetModel {
	
	//@Id
	@DynamoDBHashKey
	private long id;
	
	@DynamoDBAttribute
	private String email;
	 
	@DynamoDBAttribute
	private String tweetPost;
	
	@DynamoDBAttribute
	private Date date;
	
	@DynamoDBAttribute
	private List<String> likeBy;

	public TweetModel() {
		super();
	}

	public TweetModel(long id, String email, String tweetPost, Date date, List<String> likeBy) {
		super();
		this.id = id;
		this.email = email;
		this.tweetPost = tweetPost;
		this.date = date;
		this.likeBy = likeBy;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTweetPost() {
		return tweetPost;
	}

	public void setTweetPost(String tweetPost) {
		this.tweetPost = tweetPost;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public List<String> getLikeBy() {
		return likeBy;
	}

	public void setLikeBy(List<String> likeBy) {
		this.likeBy = likeBy;
	}
}
