package com.tweetapp.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.tweetapp.model.TweetModel;
import com.tweetapp.model.UserModel;

@Repository
public class TweetRepository {
	
	@Autowired
	private DynamoDBMapper dynamoDBMapper;
	
	public void save(TweetModel tweetModel) {
		dynamoDBMapper.save(tweetModel);
	}
	
	public TweetModel findById(long id) {
		return dynamoDBMapper.load(TweetModel.class, id);
	}
	
	public TweetModel findUserByEmail(String email) {
		return dynamoDBMapper.load(TweetModel.class, email);
	}
	
	public void deleteById(long tweetId) {
		TweetModel result = dynamoDBMapper.load(TweetModel.class, tweetId);
		dynamoDBMapper.delete(result);
	}
	
	public List<TweetModel> findAll() {
		DynamoDBScanExpression scanner = new DynamoDBScanExpression();
		List<TweetModel> result = dynamoDBMapper.scan(TweetModel.class, scanner);
		return result;
	}

}
