package com.tweetapp.repository;

//import java.util.List;
//import org.springframework.data.mongodb.repository.MongoRepository;
//import org.springframework.data.mongodb.repository.Query;
//import org.springframework.stereotype.Repository;
//
//import com.tweetapp.model.UserModel;
//
//@Repository
//public interface UserRepositoryy extends MongoRepository<UserModel, Long> {
//	
//	UserModel findByEmail(String email);
//	
//	@Query("{'email':?0}")
//	List<UserModel> findUserByEmail(String email);
//	
//} 
