package com.tweetapp.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.tweetapp.model.TweetModel;
import com.tweetapp.model.TweetReplyModel;
import com.tweetapp.model.UserModel;

@Repository
public class TweetReplyRepository {

	@Autowired
	private DynamoDBMapper dynamoDBMapper;
	
	public void save(TweetReplyModel tweetReplyModel) {
		dynamoDBMapper.save(tweetReplyModel);
	}
	
	public List<TweetReplyModel> findAll() {
		DynamoDBScanExpression scanner = new DynamoDBScanExpression();
		List<TweetReplyModel> result = dynamoDBMapper.scan(TweetReplyModel.class, scanner);
		return result;
	}
}
