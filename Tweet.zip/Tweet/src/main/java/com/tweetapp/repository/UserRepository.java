package com.tweetapp.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.tweetapp.model.UserModel;

@Repository
public class UserRepository {

	@Autowired
	private DynamoDBMapper dynamoDBMapper;

	public void save(UserModel userModel) {
		dynamoDBMapper.save(userModel);
	}

	public UserModel findUserByEmail(String email) {
		return dynamoDBMapper.load(UserModel.class, email);
	}

	
	public UserModel findById(long id) {
		return dynamoDBMapper.load(UserModel.class, id);
	}
	
	
	public List<UserModel> findAll() {
		DynamoDBScanExpression scanner = new DynamoDBScanExpression();
		List<UserModel> result = dynamoDBMapper.scan(UserModel.class, scanner);
		return result;
	}
	
}
